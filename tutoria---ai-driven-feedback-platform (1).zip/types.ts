
export enum UserRole {
  INSTRUCTOR = 'INSTRUCTOR',
  STUDENT = 'STUDENT',
  ADMIN = 'ADMIN'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface Assessment {
  id: string;
  instructorId: string;
  title: string;
  question: string;
  rubric: string;
  createdAt: string;
}

export enum SubmissionStatus {
  PENDING = 'PENDING',
  REVIEWED = 'REVIEWED'
}

export interface Submission {
  id: string;
  assessmentId: string;
  studentId: string;
  studentName: string;
  answer: string;
  status: SubmissionStatus;
  submittedAt: string;
  viewedAt?: string; // Analytics: Track when student saw feedback
}

export interface FeedbackTag {
  id: string;
  name: string;
  category: 'CONTENT' | 'STRUCTURE' | 'CRITICAL_THINKING' | 'REASONING';
}

export interface Feedback {
  id: string;
  submissionId: string;
  instructorId: string;
  content: string;
  isAiGenerated: boolean;
  wasModified: boolean; // Analytics: Did the human edit the AI draft?
  tags: string[]; // IDs
  improvementSuggestions: string[];
  interactionTime: number; // Analytics: Seconds spent by instructor
  createdAt: string;
}

export interface AiFeedbackResponse {
  feedback: string;
  suggestedTags: string[];
  improvements: string[];
}
