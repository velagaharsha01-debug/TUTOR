
import { GoogleGenAI, Type } from "@google/genai";
import { AiFeedbackResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

/**
 * Standard feedback generation using Flash for balance of speed and reasoning
 * Incorporates instructor tone and length preferences.
 */
export const generateAiFeedback = async (
  question: string,
  studentAnswer: string,
  rubric: string,
  tone: string = 'Encouraging, constructive, and academic',
  lengthPreference: 'Short' | 'Medium' | 'Long' = 'Medium'
): Promise<AiFeedbackResponse> => {
  const model = 'gemini-3-flash-preview';
  
  // Mapping length preference to approximate word counts for the LLM
  const lengthGuideline = {
    'Short': 'be concise and direct, approximately 50-80 words.',
    'Medium': 'be well-balanced and detailed, approximately 100-200 words.',
    'Long': 'be very comprehensive and deeply analytical, approximately 250-400 words.'
  }[lengthPreference];

  const prompt = `
    As an expert academic instructor, evaluate the following student submission based on the question and rubric provided.
    
    ---
    CONTEXT:
    Question: ${question}
    Student Answer: ${studentAnswer}
    Rubric/Guidelines: ${rubric}
    ---
    
    INSTRUCTIONS:
    1. Feedback Tone: ${tone}. It is critical that you maintain this specific tone throughout the message.
    2. Feedback Length: The feedback should ${lengthGuideline} Reference the student's actual text where possible.
    3. Tags: Suggest 3-5 short, professional tags (e.g., "Critical Analysis", "Needs Evidence", "Clear Structure").
    4. Improvements: Provide exactly 3 highly actionable and specific improvement steps that the student can take immediately to improve this specific work.
    
    Ensure the feedback is professional yet adheres to the chosen tone. Focus on both strengths and specific gaps relative to the rubric.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            feedback: {
              type: Type.STRING,
              description: "The main feedback message for the student, adhering to the requested tone and length guidelines."
            },
            suggestedTags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Short categorical tags for this feedback."
            },
            improvements: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 3 actionable improvement steps."
            }
          },
          required: ["feedback", "suggestedTags", "improvements"]
        }
      }
    });

    const text = response.text || "{}";
    return JSON.parse(text) as AiFeedbackResponse;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate AI feedback. Please check your connectivity or API key.");
  }
};

/**
 * Low-latency clarification service using Flash Lite for instant responses
 */
export const getClarification = async (query: string, context: string = ""): Promise<string> => {
  const model = 'gemini-flash-lite-latest';
  
  const prompt = `
    You are TutorIA, a helpful educational assistant.
    User Query: ${query}
    ${context ? `Relevant Context: ${context}` : ""}
    
    Provide a concise, helpful, and direct answer. Focus on clarity and speed.
    Use Markdown for formatting if necessary.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "I'm sorry, I couldn't process that request right now.";
  } catch (error) {
    console.error("Fast AI Error:", error);
    return "The Fast AI service is currently unavailable. Please try again in a moment.";
  }
};
