
import React, { useState } from 'react';

interface AssessmentFormProps {
  onSubmit: (title: string, question: string, rubric: string) => void;
  onCancel: () => void;
}

const AssessmentForm: React.FC<AssessmentFormProps> = ({ onSubmit, onCancel }) => {
  const [title, setTitle] = useState('');
  const [question, setQuestion] = useState('');
  const [rubric, setRubric] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title && question && rubric) {
      onSubmit(title, question, rubric);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xl p-8 max-w-2xl mx-auto mb-12">
      <h3 className="text-xl font-bold text-slate-900 mb-6">Create New Assessment</h3>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Title</label>
          <input 
            type="text" 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
            placeholder="e.g., Mid-term Reflection Paper"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Prompt / Question</label>
          <textarea 
            rows={4}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
            placeholder="What open-ended question should students answer?"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Instructor Rubric / Guidelines</label>
          <textarea 
            rows={4}
            value={rubric}
            onChange={(e) => setRubric(e.target.value)}
            className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
            placeholder="What specific criteria will you use for feedback?"
            required
          />
        </div>

        <div className="flex gap-4 pt-4 border-t border-slate-100">
          <button 
            type="button" 
            onClick={onCancel}
            className="flex-1 py-3 bg-white border border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button 
            type="submit"
            className="flex-1 py-3 bg-indigo-600 rounded-xl text-white font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
          >
            Create Assessment
          </button>
        </div>
      </form>
    </div>
  );
};

export default AssessmentForm;
